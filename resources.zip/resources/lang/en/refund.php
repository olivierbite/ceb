<?php

return [
 'refund_index'=>'index',
 'refund_update'=>'update',
 'refund_complete'=>'complete',
 'refund_cancel'=>'cancel',
 'refund_set_institution'=>'set institution',
 'refund_set_debit_account'=>'set debit account',
 'refund_set_credit_account'=>'set credit account',
 'refund_set_month'=>'set month', 
 'you_must_write_wording_for_this_transaction'=>'You must write wording for this transaction',   
  'libelle'=>'wording',
  'refun_transaction_sucessfully_registered'=>'Refun transaction sucessfully registered',
    'refund_for_the_month_of'=>'Refund for the month of ',
   'refund_by_banque'	=> 'refund by banque',
	'refund_by_salaire'				=> 'refund by salary',
	'refund_by_epargne'				=> 'refund by contribution',
	'refund_by_cautionneur'			=> 'refund by cautionneur',
	'refund_by_decompte_final'		=> 'refund by decompte final',
	'refund_by_relicats'			=> 'refund by relicats',
	'refund_by_interets_retournes'	=> 'refund by interets retournes',
	'refund_by_interets_annuels'	=> 'refund by interets annuels',
];


 