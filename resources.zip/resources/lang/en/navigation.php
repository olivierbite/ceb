<?php

return array (

  'institution'=>'Institution',

);
