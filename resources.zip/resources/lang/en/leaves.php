<?php 
return [
'leaves_view'=>'view',
 'leaves_approve'=>'approve',
 'leaves_reject'=>'reject',
 'leaves_view_my_leaves'=>'view_my_leaves',
 'leaves_request_leaves'=>'request_leaves',
 'leaves_view_leave_status'=>'view_leave_status',



]; ?>