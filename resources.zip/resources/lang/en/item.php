<?php

return [
'id'=>'Id',
'name'=>'Name',
'add'=>'Add',
'price'=>'Price',
'quantity'=>'Quantity',
'description'=>'Description',
'item'=>'Items',
'items_inventory'=>'Items inventory',
 
];
