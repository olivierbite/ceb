<?php

return [
    'select_institution'=>'Select Institution',
    'institutions_view'=>'Institutions view'
   ];

