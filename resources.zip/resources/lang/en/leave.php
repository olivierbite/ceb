<?php 
return [
'leave-icon' =>'fa fa-calendar',
'rejected-icon' =>'fa fa-close text-red',   
'approved-icon' =>'fa fa-check text-green',   
 'Leaves_Management'=>'Leaves Management',
 'new_leave'=>'New Leave',
 'user'=>'User',
 'backup'=>'Backup',
 'phone'=>'Phone',
 'days'=>'Days',
 'start_date'=>'Start Date',
 'end_date'=>'End Date',
 'status'=>'Status',
 'action'=>'Action',
 'approve'=>'Approve',
 'reject'=>'Reject',
 'Apply_for_leave_here'=>'Apply for leave here',
 'number_of_days'=>'Number of days',
 'Start_Date'=>'Start Date',
 'to'=>'To',
'leaves_view'=>'view',
 'leaves_approve'=>'approve',
 'leaves_reject'=>'reject',
 'leaves_view_my_leaves'=>'view_my_leaves',
 'leaves_request_leaves'=>'request_leaves',
 'leaves_view_leave_status'=>'view_leave_status',



]; ?>