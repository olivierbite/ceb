
<?php

return [
    'ceb_view_own_profile'=>'view own profile ',
   
];
