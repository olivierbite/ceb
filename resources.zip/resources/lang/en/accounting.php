<?php

return array (
   'accounting_accounting'                                  =>'Accounting',
   'accounting_debit_account'                               =>'Debit Account',
   'accounting_creditt_account'                             =>'Credit Account',
   'accounting_amount'                                      =>'Amount',
   'accounting_view'                                        =>'View',
   'accounting_posting'                                     =>'Posting',
   'accounting'                                             =>'Accounting',
   'debit_account'                                          =>'Account',
   'amount'                                                 =>'Amount',
   'creditt_account'                                        =>'Account',
   'amount'                                                 =>'Amount',
   'journal'                                                =>'Journal',
   'wording'                                                =>'wording',
   'cheque_number'                                          =>'cheque number',
   'bank'                                                   =>'Bank',
   'transaction_is_recorded_successfully_transaction_id_is' =>'Transaction recorded successfully, Transaction ID is :transactionid',

	);