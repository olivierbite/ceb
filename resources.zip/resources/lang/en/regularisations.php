<?php

return [
'regularisation'=>'Regularisation',
 
];
