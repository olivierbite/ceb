<?php

return [

'items_inventory'=>'Items inventory',
 
];