<?php

return [
    'account_list'=>'List',
    'account_create'=>'Create',
    'date'=>'Date',
    'wording'=>'Wording',
    'debit'=>'Debit',
    'credit'=>'Credit',
    
];
