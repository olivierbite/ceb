<?php

return [
    'name'=>'Name',
    'permissions'=>'Permissions',
    'select_ceb_view_own_profile_if_you_want_people_of_this_group_to_only_see_their_profile'=>'Select ceb view own profile if you want people of this group to only see their profile',
    
];
