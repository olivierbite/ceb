<?php

return [
   
    'attornies_add'=>'add',
    'names'=>'Names',
   
        
];
