<?php

return array (
  'please_search_for_a_member_in_the_above_search_box_before_you_continue' => 'Please search for a member in the above search box before you continue',
  'upload_photo' => 'Upload photo',
  'photo_selected' => 'Photo selected',
  'upload_signature' => 'Upload signature',
  'signature_selected' => 'Signature selected ',
  'are_you_sure_you_want_to_delete_this_item' => 'Are you sure you want to delete this item?',
  'saving' => 'Save',
  'cancel' => 'Cancel',
  'regularisation_view'=>'Regularisation view',
  'amount_installments'=>'Amount  and  Installments',
  'this_member_has_0_remaining_right_to_loan'=>'This member has 0 remaining right to loan',
  'amount'=>'Amount',
  'installments'=>'Installments',
);
