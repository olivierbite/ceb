<?php

return [
    'version'=>'Version',
    'copy_right'=>'Copy Right ',
    'ceb'=>'CEB',
    'all_right_reserved'=>'All Right Reserved',
    
];
