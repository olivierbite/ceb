<?php

return array (
     'reports_index'=>'index',
 'reports_contract_saving'=>'saving',
 'reports_contract_loan'=>'contract loan',
 'reports_member'=>'member',
 'reports_accounting_piece'=>'accounting piece',
 'reports_ledger'=>'ledger',
 'reports_bilan'=>'bilan',
 'reports_journal'=>'journal',
 'reports_accounts_list'=>'accounts list',
 'reports_loans_records'=>'loans records',
 'reports_contributions'=>'contributions',
  'report_range'=>'Report range',
  'export_excel'=>'Export Excel',
  'select_loan_status'=>'Select loan status',
   'all_loans'=>'All loans',
   'member_loan_records_file'=>'Laon records file',
   'member_contribution_file'=>'Contribution records file',
   'select_account'  =>'Select account',

      'transaction_id'=>'Transaction id',
      'select_institution'=>'Institution',

    );