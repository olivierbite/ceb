<?php

return [
    'ordinary_loan'=>'Ordinary Loan',
    'urgent_ordinary_loan'=>'Urgent ordinary Loan',
    'special_loan'=>'Special Loan',
    'social_loan'=>'Social Loan',
    'emergency_loan'=>'Emergency Loan',
];
