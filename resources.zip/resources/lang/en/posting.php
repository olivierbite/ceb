<?php

return array (
  'transactionid' => 'Transaction id',
  'date'=>'Date',
  'wording'=>'Wording',
  'account_number'=>'Account number',
  'debit'=>'Debit',
  'credit'=>'Credit',
'movement_total'=>'Total movements'  

);
