
<?php

return [
    'files_view'=>'View',
 'files_add'=>'Add',
   
];
