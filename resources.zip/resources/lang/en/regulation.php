<?php

return [
'completed_installments_regulation_successfully'=>'Completed installments regulation successfully',
 
];
