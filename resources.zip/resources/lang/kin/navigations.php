<?php

return array (
  'dashboard' => 'Dashboard',
  'members' => 'Members',
  'contributions_and_savings' => 'Contributions & savings',
  'loans_and_repayments' => 'Loans & repayments',
  'accounting' => 'Accounting',
  'reports' => 'Reports',
  'settings' => 'Settings',
  'institutions' => 'institutions',
  'accounting_plan' => 'Accounting plan',
  'closing_exercise' => 'Closing Exercise',
  'contributions' => 'Contributions',
);
