<?php

return array (
  'institutions' => 'Institutions',
  'month' => 'Ukwezi',
  'date' => 'Date',
  'totalAmount' => 'Total amount',
  'debit_account' => 'Debit account',
  'credit_account' => 'Credit account',
  'complete_transaction' => 'Complete transaction',
  'cancel_transaction' => 'Cancel transaction',
);
