<?php

return array (
  'adhersion_number' => 'Adhersion #',
  'names' => 'Names',
  'institution' => 'Institution',
  'service' => 'Service',
  'nid' => 'National ID',
  'district' => 'District',
  'adhersion_date' => 'Adhersion date',
  'monthly_fee' => 'Monthly fees',
  'add' => 'Ongera',
  'count_of_members' => 'Umubare w\' abanyamuryango',
);
