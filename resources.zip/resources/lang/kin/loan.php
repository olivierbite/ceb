<?php

return array (
  'ordinary_loans' => 'Inguzanyo isanzwe',
);
