<?php

return array (
  'sorry_there_is_no_item_here' => 'Sorry, there is no item here',
  'upload_photo' => 'Upload photo',
  'photo_selected' => 'Photo selected',
  'upload_signature' => 'Upload signature',
  'signature_selected' => 'Signature selected',
  'are_you_sure_you_want_to_delete_this_item' => 'Are you sure you want to delete this item?',
);
