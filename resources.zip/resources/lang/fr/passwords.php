<?php

return array (
  'password' => 'Votre  mot de passe  doit avoir  au moins  six  caractère et la  confirmation de même   ',
  'user' => 'L\'utilisateur  de ce  email  n\'est pas  trouve dans le  system',
  'token' => 'Le  jeton  de  votre mot de passe  est incorrect.',
  'sent' => 'Nous  vous a  envoyé email  de la réinitialisation de  votre mot de passe',
  'reset' => 'Votre  mot de passe   a ete  reinitialise',
  'throttle' => 'Quitter',
);
