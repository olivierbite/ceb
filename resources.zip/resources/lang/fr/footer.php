<?php

return [
    'version'=>'Version',
    'copy_right'=>'Droits d\' Auteur',
    'ceb'=>'CEB',
    'all_right_reserved'=>'Tous  Droits Reserve',
    
];
