<?php

return [
    'ordinary_loan'=>'prêt ordinaire',
    'urgent_ordinary_loan'=>'prêt ordinaire urgent',
    'special_loan'=>'prêt special',
    'social_loan'=>'prêt social',
    'emergency_loan'=>'prêt urgence',
];
