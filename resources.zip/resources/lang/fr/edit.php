<?php

return [
    'groups'=>'Groupes',
   
];
