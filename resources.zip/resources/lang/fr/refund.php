<?php

return [
 'refund_index'=>'index',
 'refund_update'=>'Mise a Jour',
 'refund_complete'=>'Complete',
 'refund_cancel'=>'Annuler',
 'refund_set_institution'=>'Mettre institution',
 'refund_set_debit_account'=>'Mettre debit account',
 'refund_set_credit_account'=>'Mettre credit account',
 'refund_set_month'=>'Mettre Mois',    
 'you_must_write_wording_for_this_transaction'=>'Vous  deviez rempliere le libelle de cette transaction',
  'libelle'=>'Libelle',
    'refun_transaction_sucessfully_registered'=>'Transaction pour remboursement enrgistre avec success',
    'refund_for_the_month_of'=>'Remboursement du mois de ',
    'refund_by_banque'	=> 'Remboursement par banque',
	'refund_by_salaire'				=> 'Remboursement par salaire',
	'refund_by_epargne'				=> 'Remboursement par epargne',
	'refund_by_cautionneur'			=> 'Remboursement par cautionneur',
	'refund_by_decompte_final'		=> 'Remboursement par decompte final',
	'refund_by_relicats'			=> 'Remboursement par relicats',
	'refund_by_interets_retournes'	=> 'Remboursement par interets retournes',
	'refund_by_interets_annuels'	=> 'Remboursement par interets annuels',
	'refund_type'=>'Moyen de rembursement',
];


 