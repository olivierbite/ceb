<?php

return [
    'name'=>'Nom',
    'permissions'=>'Permissions',
    'select_ceb_view_own_profile_if_you_want_people_of_this_group_to_only_see_their_profile'=>'Selectionner vue CEB si  vous voulez que l\'utilisateur  regard seulement son profile',
    
];
