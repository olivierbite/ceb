<?php

return [
    'select_institution'=>'sélectionner Institution',
    'institutions_view'=>'Vue Institution'
   ];

