
<?php

return [
    'files_view'=>'Vue',
 'files_add'=>'Ajouter',
   
];
