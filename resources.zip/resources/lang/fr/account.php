<?php

return [
    'account_list'=>'List',
    'account_create'=>'Cree',
    'date'=>'Date',
    'wording'=>'Libelle',
    'debit'=>'Debit',
    'credit'=>'Credit',
    'account_number'=>'Compte numero',
    'account_entitled'=>'Intitule',
    'titled'=> 'Intitule',
    'account_nature'=>'Nature',
    'balance'=>'Solde',
];
