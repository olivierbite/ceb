<?php

return [
'id'=>'Id',
'name'=>'Nom',
'add'=>'Ajouter',
'price'=>'Prix',
'quantity'=>'Quantite',
'description'=>'Description',
'item'=>'Articles',
'items_inventory'=>'Inventaire des Articles',
 
];