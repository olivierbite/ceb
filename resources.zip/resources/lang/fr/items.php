<?php

return [

'items_inventory'=>'Inventaire des Articles',
'item'=>'Article',
 
];