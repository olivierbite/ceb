<?php

return array (
     'reports_index'=>'index',
 'reports_contract_saving'=>'Contract d\'Epargne',
 'reports_contract_loan'=>'Contract de prêts',
 'reports_member'=>'Membre',
 'reports_accounting_piece'=>'Piece Comptable',
 'reports_ledger'=>'Grand Livre',
 'reports_bilan'=>'Bilan',
 'reports_journal'=>'Journal',
 'reports_accounts_list'=>'Plan Comptable',
 'reports_loans_records'=>'Fiche de prêts',
 'reports_contributions'=>'Epargne',
 'report_range'=>'Report range',
 'export_excel'=>'Export Excel',
   'select_loan_status'=>'Selectionne status du prêts',
   'all_loans'=>'All loans',
   'member_loan_records_file'=>'Fiche de prêts',
   'member_contribution_file'=>'Fiche de cotisations',
   'select_account'  =>'Selectionner compte',
      'reports_piece_disbursed_saving'=>'Rapport piece debourse epargne',
      'transaction_id'=>'Numero document',
       'approved_loans'=>'Prêts approuve/actroyer',
       'montly_refunds_per_institution'=>'Liste de  remboursement mensuel par institution',
       'select_institution'=>'Institution',
       'bilan'=>'Bilan entre',
       'reports_savings_level'=>'Rapport niveau epargne',
       'level_of_savings_per_member'=>'Niveau de l\'epargne par membre',
       'member_who_are_not_contributing'=>'Irrégularités des cotisations',
       'member_with_irregularite_in_refunding'=>'Remboursements irréguliers',
       'accounts_list'=>'Liste des comptes',
       'ledger'=>'Grand Livre',
       'journal'=>'Journal',
       'Bilan'=>'Bilan',

1  

  );