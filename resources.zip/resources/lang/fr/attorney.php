<?php

return [
   
    'created'=>'Mandataire cree avec success',
  
   
        
];
