<?php

return array (
  'status' => 'Status',
 );