<?php

return [
   
    'members_are_removed_from_this_contribution_session'=>'Membres sont retirés de cette session de contribution',
 
];
