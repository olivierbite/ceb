<?php

return array (

	'accounting_accounting'=>'Comptabilite',
	'accounting_debit_account'=>'Compte Debit',
  'accounting_creditt_account'=>'Compte Credit',
   'accounting_amount'=>'Montant',
   'accounting_view'=>'Vue',
   'accounting_posting'=>'Posting',
  'accounting'=>'Comptabilite',
   'debit_account'=>'Compte',
   'amount'=>'Montant',
   'creditt_account'=>'Compte',
   'amount'=>'Montant',
    'journal'=>'Journal',
      'wording'=>'Libelle',
  'cheque_number'=>'Numero de  cheque',
  'bank'=>'Banque',	
  'you_have_done_accounting_transaction_successfully'=>'Transaction comptable effectue  avec success',

   'accounting_accounting'                                  =>'Comptabilite',
   'accounting_debit_account'                               =>'Compte Debit',
   'accounting_creditt_account'                             =>'Compte Credit',
   'accounting_amount'                                      =>'Montant',
   'accounting_view'                                        =>'Vue',
   'accounting_posting'                                     =>'Posting',
   'accounting'                                             =>'Comptabilite',
   'debit_account'                                          =>'Compte',
   'amount'                                                 =>'Montant',
   'creditt_account'                                        =>'Compte',
   'amount'                                                 =>'Montant',
   'journal'                                                =>'Journal',
   'wording'                                                =>'Libelle',
   'cheque_number'                                          =>'Numero de  cheque',
   'bank'                                                   =>'Banque',	
   'transaction_is_recorded_successfully_transaction_id_is' =>'Transaction enregistrée avec succès , ID de transaction est :transactionid',


  );