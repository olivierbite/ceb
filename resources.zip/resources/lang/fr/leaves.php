<?php 
return [
'leaves_view'=>'view',
 'leaves_approve'=>'approve',
 'leaves_reject'=>'reject',
 'leaves_view_my_leaves'=>'Voir me Congés',
 'leaves_request_leaves'=>'Demande le Congé',
 'leaves_view_leave_status'=>'Voir le status de  congés',



]; ?>