<?php

return array (
  'previous' => '« Precedent',
  'next' => 'Suivant »',
);
