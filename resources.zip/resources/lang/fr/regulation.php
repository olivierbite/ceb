<?php

return [
'completed_installments_regulation_successfully'=>'Regularisation echeance sauvegarde  avec succes',
 
];
