
<?php

return [
    'ceb_view_own_profile'=>'Vue Profile pour lui meme',
   
];
