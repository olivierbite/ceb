<?php

return [
   
    'attornies_add'=>'Ajouter',
    'names'=>'Noms',
    'nid'=>'ID'
        
];
