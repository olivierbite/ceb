<?php

return array (
  'please_search_for_a_member_in_the_above_search_box_before_you_continue' => 'Veillez  cherche  membre',
  'upload_photo' => 'Charge photo',
  'photo_selected' => 'Photo Selectionne',
  'upload_signature' => 'Charge signature', 
  'signature_selected' => 'Signature selectionne',
  'are_you_sure_you_want_to_delete_this_item' => 'Voulez vous efface  cette item?',
  'saving' => 'Sauvegarde',
  'cancel' => 'Annuler',
  'regularisation_view'=>'Vue Regularisation',
   'amount_installments'=>'Montant et Echeances',
   'installments'=>'Echeances',

  'this_member_has_0_remaining_right_to_loan'=>'Ce membre n\'a plus le doit au  regularisation',


   'amount'=>'Montant',
);
