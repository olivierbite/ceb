<?php 
return [
'leave-icon' =>'fa fa-calendar',
'rejected-icon' =>'fa fa-close text-red',   
'approved-icon' =>'fa fa-check text-green',   
 'Leaves_Management'=>'Gestion Congés',
 'new_leave'=>'Nouveau Congés',
 'user'=>'Utilisateur',
 'backup'=>'Remplaçant',
 'phone'=>'Phone',
 'days'=>'Jours',
 'start_date'=>'Date Debut',
 'end_date'=>'Date Fin',
 'status'=>'Status',
 'action'=>'Action',
 'approve'=>'Approve',
 'reject'=>'Rejete',
 'Apply_for_leave_here'=>'Demande de congé ici',
 'number_of_days'=>'Nombres  des  jours',
 'Start_Date'=>'Date Debut',
  'to'=>'Jusqu\'',



]; ?>