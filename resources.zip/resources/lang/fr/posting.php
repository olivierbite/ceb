<?php

return array (
  'transactionid' => 'Transaction id',
  'date'=>'Date',
  'wording'=>'Libelle',
  'account_number'=>'Numero compte',
  'debit'=>'Debit',
  'credit'=>'Credit',
  'movement_total'=>'Total des mouvements',

);
