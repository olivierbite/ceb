<div class="row">
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" >
	<a href="#"
	   class="col-xs-12 col-sm-12 col-md-12 col-lg-12 btn btn-lg btn-success">
	  {{ trans('loans.give_loan') }}
	</a>
</div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" >
	<a href="#"
	   class="col-xs-12 col-sm-12 col-md-12 col-lg-12 btn btn-lg btn-primary">
	   {{ trans('repayments.register_repayment') }}
	</a>
</div>
</div>
