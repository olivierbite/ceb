    <!-- Bootstrap 3.3.4 -->
    <link href="{{Url()}}/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />

    <!-- Font Awesome Icons -->
    <link href="{{Url()}}/assets/fontawesome/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- sweet alert -->
    <link href="{{Url()}}/assets/dist/css/sweetalert.css" rel="stylesheet" type="text/css" />


    <!-- Ionicons -->
    <link href="{{Url()}}/assets/ionicons/ionicons.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="{!! Url() !!}/assets/dist/css/select2.min.css" />
    <!-- Theme style -->
      <link href="{{Url()}}/assets/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <link href="{{Url()}}/assets/dist/css/ceb.css" rel="stylesheet" type="text/css" />
     <link href="{{Url()}}/assets/dist/css/jquery.popdown.css" rel="stylesheet" type="text/css" />
    <!-- CEB Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
 
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript">
    /**
 * Open a URL in a new tab using JavaScript
 * @param 
 */
function OpenInNewTab(url) {
  var win = window.open(url, '_blank');
  win.focus();
}
</script>

    