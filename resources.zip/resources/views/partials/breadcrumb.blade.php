<ol class="breadcrumb">
      <strong>{{ trans('general.date') }}  {!! date('d-M-Y') !!} </strong>
</ol>
