<style type="text/css" media="print">
  @page { size: landscape; }
  font-size:9;
</style>