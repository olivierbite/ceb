  <head>
    <meta charset="UTF-8">
    <title>CEB | @yield('content_title')</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @include('partials.css')
  </head>