<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>{{ trans('footer.version') }}</b> 2.0
        </div>
        <strong> <a href="http://huguka.com" target="_blank">{{ trans('footer.ceb') }} </a>.</strong>
</footer>