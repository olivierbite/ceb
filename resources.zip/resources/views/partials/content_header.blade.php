<section class="content-header">
          <h1>
            @yield('content_title')
            <small>@yield('content_descriptions')</small>
          </h1>

@include('partials.breadcrumb')
</section>