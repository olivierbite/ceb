<p>
  Hi,
</p>
<p>
Kindly be informed that the leave you have reqeusted is {!! $status !!}.
</p>
<hr>
<p>
 Regards.
</p>
<p>
 CEB Butare team.
</p>