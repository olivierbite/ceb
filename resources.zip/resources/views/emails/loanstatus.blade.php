<p>
  Hi {{ $names }},
</p>
<p>
 The loan you have  requested is {!! $status !!}.
</p>
<hr>
<p>
 Regards.
</p>
<p>
 CEB Butare team.
</p>