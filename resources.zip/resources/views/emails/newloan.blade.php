<p>
  Hi {{ $names }}
</p>
<p>
 We have received your request for the loan worth of  <code>{{ $amount }}</code> Rwf, and it is under approval process.
</p>
<hr>
<p>
 Regards.
</p>
<p>
 CEB Butare team.
</p>