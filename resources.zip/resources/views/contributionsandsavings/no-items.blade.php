<tr>
	<td colspan="4" class="ui centered">{{ trans('general.sorry_there_is_no_item_here') }}</td>
</tr>