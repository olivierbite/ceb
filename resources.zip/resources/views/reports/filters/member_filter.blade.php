@extends('reports.layouts.popup')

@section('content')
 @include('members.search')
@stop