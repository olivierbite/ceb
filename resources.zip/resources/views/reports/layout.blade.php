<div class="row">
	@include('reports.dashboard')
</div>
<div class="row">
	@include('reports.partials.reports_category')
</div>