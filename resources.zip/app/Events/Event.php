<?php

namespace Ceb\Events;

abstract class Event
{
    //
}
