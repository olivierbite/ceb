<?php

namespace Ceb\Models;
class File extends Model {

}
