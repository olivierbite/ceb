<?php

namespace Ceb\Models;
use Ceb\Models\Model;

class AssetType extends Model {
	//
}
