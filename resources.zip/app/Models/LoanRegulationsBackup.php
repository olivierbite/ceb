<?php 

namespace Ceb\Models;

use Illuminate\Support\Facades\DB;

class LoanRegulationsBackup extends Model {

	protected  $table = 'loan_regulations_backup';
}