<?php

namespace Ceb\Models;

class Membershipfee extends Model {
	//
}
