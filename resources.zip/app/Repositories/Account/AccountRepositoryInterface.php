<?php
namespace Ceb\Repositories\Account;
/**
 * AccountRepositoryInterface
 */
interface AccountRepositoryInterface {
	function getAll();
	function lists();
}